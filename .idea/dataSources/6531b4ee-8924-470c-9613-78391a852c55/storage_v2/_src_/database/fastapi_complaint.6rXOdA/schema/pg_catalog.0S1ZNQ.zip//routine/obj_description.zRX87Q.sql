create function obj_description(oid) returns text
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT pg_description.description
    FROM pg_description
   WHERE ((pg_description.objoid = $1) AND (pg_description.objsubid = 0));
END;

comment on function obj_description(oid) is 'deprecated, use two-argument form instead';

alter function obj_description(oid) owner to "postgres-user";

